from django.urls import path
from . import views

urlpatterns = [
    path('api/forms/templates/', views.get_form_templates),
    path('api/employees/', views.save_employee),
]
