from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

from .views import (
    RegisterView, ChangePasswordView, ProfileView,
    FormTemplateViewSet, EmployeeViewSet
)

router = DefaultRouter()
router.register("forms/templates", FormTemplateViewSet, basename="formtemplate")
router.register("employees", EmployeeViewSet, basename="employee")

urlpatterns = [
    # auth
    path("auth/register/", RegisterView.as_view()),
    path("auth/token/", TokenObtainPairView.as_view()),
    path("auth/token/refresh/", TokenRefreshView.as_view()),
    path("auth/change-password/", ChangePasswordView.as_view()),
    path("auth/profile/", ProfileView.as_view()),
]

urlpatterns += router.urls
