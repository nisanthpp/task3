from django.db import models
from django.contrib.auth.models import User

class FormTemplate(models.Model):
    name = models.CharField(max_length=120)
    description = models.TextField(blank=True, default="")
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class FormField(models.Model):
    TEXT = "text"
    NUMBER = "number"
    DATE = "date"
    PASSWORD = "password"
    EMAIL = "email"
    SELECT = "select"
    FIELD_TYPES = [
        (TEXT, "Text"),
        (NUMBER, "Number"),
        (DATE, "Date"),
        (PASSWORD, "Password"),
        (EMAIL, "Email"),
        (SELECT, "Select"),
    ]

    template = models.ForeignKey(FormTemplate, related_name="fields", on_delete=models.CASCADE)
    label = models.CharField(max_length=120)
    field_type = models.CharField(max_length=20, choices=FIELD_TYPES, default=TEXT)
    required = models.BooleanField(default=False)
    order = models.PositiveIntegerField(default=0)
    placeholder = models.CharField(max_length=120, blank=True, default="")
    options = models.JSONField(blank=True, null=True, help_text="Only for select")

    class Meta:
        ordering = ["order", "id"]
        unique_together = ("template", "label")

    def __str__(self):
        return f"{self.template.name}: {self.label}"

class Employee(models.Model):
    template = models.ForeignKey(FormTemplate, on_delete=models.PROTECT, related_name="employees")
    data = models.JSONField(default=dict)  # responses by label
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Employee #{self.id} ({self.template.name})"
