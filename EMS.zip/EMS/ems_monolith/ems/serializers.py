from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers
from .models import FormTemplate, FormField, Employee

# --- Auth ---
class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    class Meta:
        model = User
        fields = ["id", "username", "email", "password"]
    def create(self, validated_data):
        return User.objects.create_user(
            username=validated_data["username"],
            email=validated_data.get("email", ""),
            password=validated_data["password"]
        )

class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField()
    new_password = serializers.CharField()
    def validate_new_password(self, value):
        validate_password(value); return value

class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "username", "email", "first_name", "last_name"]

# --- Dynamic Forms ---
class FormFieldSerializer(serializers.ModelSerializer):
    class Meta:
        model = FormField
        fields = ["id", "label", "field_type", "required", "order", "placeholder", "options"]

class FormTemplateSerializer(serializers.ModelSerializer):
    fields = FormFieldSerializer(many=True)
    class Meta:
        model = FormTemplate
        fields = ["id", "name", "description", "fields", "created_at"]

    def create(self, validated_data):
        fields_data = validated_data.pop("fields", [])
        template = FormTemplate.objects.create(**validated_data)
        for idx, f in enumerate(fields_data):
            FormField.objects.create(template=template, order=f.get("order", idx), **f)
        return template

    def update(self, instance, validated_data):
        fields_data = validated_data.pop("fields", None)
        for k, v in validated_data.items():
            setattr(instance, k, v)
        instance.save()
        if fields_data is not None:
            instance.fields.all().delete()
            for idx, f in enumerate(fields_data):
                FormField.objects.create(template=instance, order=f.get("order", idx), **f)
        return instance

# --- Employees ---
class EmployeeSerializer(serializers.ModelSerializer):
    template_name = serializers.CharField(source="template.name", read_only=True)
    class Meta:
        model = Employee
        fields = ["id", "template", "template_name", "data", "created_at", "updated_at"]

    def validate(self, attrs):
        template = attrs.get("template") or getattr(self.instance, "template", None)
        data = attrs.get("data", {})
        if not isinstance(data, dict):
            raise serializers.ValidationError({"data": "Must be JSON object keyed by labels"})
        if template:
            req = [f.label for f in template.fields.all() if f.required]
            missing = [lbl for lbl in req if (lbl not in data or data[lbl] in [None, "", []])]
            if missing:
                raise serializers.ValidationError({"data": f"Missing required fields: {', '.join(missing)}"})
        return attrs
