from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.models import User
from rest_framework import viewsets, permissions, generics, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt


from .models import FormTemplate, Employee
from .serializers import (
    RegisterSerializer, ChangePasswordSerializer, ProfileSerializer,
    FormTemplateSerializer, EmployeeSerializer
)

# --- Auth API ---
class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer
    permission_classes = [permissions.AllowAny]

class ChangePasswordView(APIView):
    def post(self, request):
        s = ChangePasswordSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        user = request.user
        if not user.check_password(s.validated_data["old_password"]):
            return Response({"detail":"Old password incorrect"}, status=status.HTTP_400_BAD_REQUEST)
        user.set_password(s.validated_data["new_password"]); user.save()
        update_session_auth_hash(request, user)
        return Response({"detail":"Password changed"})

class ProfileView(generics.RetrieveUpdateAPIView):
    serializer_class = ProfileSerializer
    def get_object(self): return self.request.user

# --- Form Templates API ---
class FormTemplateViewSet(viewsets.ModelViewSet):
    queryset = FormTemplate.objects.all().order_by("-id")
    serializer_class = FormTemplateSerializer

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

# --- Employees API ---
class EmployeeViewSet(viewsets.ModelViewSet):
    serializer_class = EmployeeSerializer

    def get_queryset(self):
        qs = Employee.objects.all().order_by("-id")
        q = self.request.query_params.get("q")
        label = self.request.query_params.get("label")
        value = self.request.query_params.get("value")
        if q:
            ids = [e.id for e in qs if any(q.lower() in str(v).lower() for v in (e.data or {}).values())]
            return qs.filter(id__in=ids)
        if label and value is not None:
            ids = [e.id for e in qs if value.lower() in str((e.data or {}).get(label, "")).lower()]
            return qs.filter(id__in=ids)
        return qs

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)



# Sample data — replace with DB query if you have models
FORM_TEMPLATES = [
    {
        "id": 1,
        "name": "Basic Employee Info",
        "fields": [
            {"label": "Name", "field_type": "text", "required": True, "placeholder": "Full Name"},
            {"label": "Email", "field_type": "email", "required": True, "placeholder": "Email Address"},
            {"label": "Joining Date", "field_type": "date", "required": True},
            {"label": "Department", "field_type": "select", "options": ["HR", "IT", "Finance"], "required": True}
        ]
    }
]

def get_form_templates(request):
    return JsonResponse(FORM_TEMPLATES, safe=False)

@csrf_exempt
def save_employee(request):
    if request.method == 'POST':
        import json
        data = json.loads(request.body)
        # Save to DB here — data['template'], data['data']
        return JsonResponse({"status": "success"})